#!/usr/bin/env python3
"""Open problem 2: is the guaranteed horizon d(p) of Theorem 3 sharp at precision p?
A terminal state whose candidate set meets BOTH images at depth d(p) yields two (d(p)+1)-step
control words, differing in their first control, that reach it from starts in I_p.  Exact integers."""
import sys, random, time
from paper_checks import Q, lattice_constants, abs_slope, horizon, FS, preimage

def depth(h, p, E, a, b, cap):
    C = (h, h); out = []
    for _ in range(cap):
        hits = [f for f in FS if not (C[1] < E[f][0] or C[0] > E[f][1])]
        if len(hits) == 2: return out, C, 'both'
        if not hits: return out, C, 'empty'
        f = hits[0]; out.append(f)
        C = preimage(max(C[0], E[f][0]), min(C[1], E[f][1]), f, a, b, p)
        if C is None: return out, None, 'empty'
    return out, C, 'cap'

def witness(h, p, E, a, b, out, C):
    """Build and verify the two words."""
    y1 = min(C[1], E[1094][1]); y2 = max(C[0], E[1096][0])
    x1 = preimage(y1, y1, 1094, a, b, p)[0]; x2 = preimage(y2, y2, 1096, a, b, p)[0]
    w = out[::-1]
    def run(x, ctrl):
        for f in ctrl: x = Q(x, f, p)
        return x
    e1, e2 = run(x1, [1094] + w), run(x2, [1096] + w)
    assert e1 == e2 == h
    return x1, x2, ''.join('L' if f == 1094 else 'H' for f in w)

if __name__ == "__main__":
    rng = random.Random(2026)
    for p in range(6, 23):
        a, b, e1, e2, G = lattice_constants(p)
        E = {1094: (a, e1), 1096: (e2, b)}
        mu = min(abs_slope(a, f, p) for f in FS)
        d, _ = horizon(mu, G)
        size = b - a + 1
        exhaustive = size <= 400000
        pool = range(a, b + 1) if exhaustive else (rng.randint(a, b) for _ in range(10**9))
        t0 = time.time(); tried = 0; found = None; mind = None
        for h in pool:
            tried += 1
            out, C, why = depth(h, p, E, a, b, d + 1)
            if why == 'both':
                mind = len(out) if mind is None else min(mind, len(out))
                assert len(out) >= d
                if len(out) == d:
                    found = witness(h, p, E, a, b, out, C) + (h,); break
            if not exhaustive and time.time() - t0 > 25: break
        mode = 'exhaustive' if exhaustive else 'random'
        if found:
            x1, x2, w, h = found
            print(f"p={p:2d} d={d:2d}: SHARP (witness after {tried} {mode} states): end {h}, starts {x1} [L] / {x2} [H], shared {w}")
        else:
            print(f"p={p:2d} d={d:2d}: no witness in {tried} {mode} states (min ambiguous depth seen: {mind})")
        sys.stdout.flush()

# Exhaustive exact horizon at p = 6 and p = 7 (Proposition 2'):
#   from witness_search import depth, witness
#   scan every h in I_p with cap 60 and take the minimum depth at which the candidate set meets both images.
#   Result: p = 6 -> 7 (= bound), p = 7 -> 10 (bound 9); p = 7 witness: starts 854680 [L] / 892572 [H],
#   shared HHHLHLHLHL, end 854691.
