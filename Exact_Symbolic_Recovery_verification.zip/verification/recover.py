#!/usr/bin/env python3
"""
Symbolic recoverability: from a terminal lattice state alone, how many preceding controls are determined?
Open-loop system on the exact 10^-14 lattice; controls are external. Exact integers throughout.

Recovery procedure (exact):
  C := {H_N}.  For j = 0, 1, ...:
    if C meets only image(F=1.094) or only image(F=1.096): that branch is control F_{N-1-j};
       C := C ∩ image(branch);  C := preimage of C under that branch, within I  (an interval: fwd is non-increasing)
    else: stop (two control suffixes are consistent; uniqueness is lost at depth j).
"""
import random, math
from fractions import Fraction as Fr

A_, B_ = 8546797095098, 8925729498786
D42, HALF = 10**42, 10**42 // 2
FS = (1094, 1096)

def fwd(h, f):
    q, r = divmod((h*h - f*10**25)**2 - f*10**53, D42)
    if r > HALF or (r == HALF and q & 1): q += 1
    return q

IMG = {f: (fwd(B_, f), fwd(A_, f)) for f in FS}          # fwd is non-increasing on I
GAP = IMG[1096][0] - IMG[1094][1] - 1                    # lattice points strictly between the images

def preimage(lo, hi, f):
    """Lattice points h in I with lo <= fwd(h,f) <= hi, as an interval (or None)."""
    # smallest h with fwd(h) <= hi
    L, R = A_, B_ + 1
    while L < R:
        m = (L + R) // 2
        if fwd(m, f) <= hi: R = m
        else: L = m + 1
    h1 = L
    # largest h with fwd(h) >= lo
    L, R = A_ - 1, B_
    while L < R:
        m = (L + R + 1) // 2
        if fwd(m, f) >= lo: L = m
        else: R = m - 1
    h2 = L
    return (h1, h2) if h1 <= h2 else None

def recover(hN, maxdepth):
    C = (hN, hN); out = []; widths = []
    for _ in range(maxdepth):
        hits = [f for f in FS if not (C[1] < IMG[f][0] or C[0] > IMG[f][1])]
        if len(hits) != 1:
            return out, widths, 'ambiguous' if len(hits) == 2 else 'empty'
        f = hits[0]; out.append(f)
        C = (max(C[0], IMG[f][0]), min(C[1], IMG[f][1]))
        C = preimage(C[0], C[1], f); widths.append(C[1] - C[0] + 1)
        if C is None: return out, widths, 'empty'
    return out, widths, 'maxdepth'

def guaranteed_depth():
    """Worst-case bound: n_{j+1} <= n_j / s + 1 lattice points, n_0 = 1; depth j is decidable while n_j <= GAP + 1."""
    s = min(4*Fr(A_, 10**14)*(Fr(f, 1000) - Fr(A_, 10**14)**2) for f in FS)   # |P'| is smallest at a
    n, j = Fr(1), 0
    while n <= GAP + 1:
        j += 1; n = n / s + 1
    return j, float(s)

if __name__ == "__main__":
    rng = random.Random(7)
    print(f"Images: F=1.094 -> {IMG[1094]},  F=1.096 -> {IMG[1096]},  gap = {GAP} lattice points")
    jg, s = guaranteed_depth()
    print(f"Proven worst case (s_min = {s:.4f}): every terminal state determines its last min(N, {jg}) controls\n")

    N = 80; depths = []; wrong = 0; reasons = {}
    for t in range(3000):
        h = rng.randint(A_, B_); ctrl = [rng.choice(FS) for _ in range(N)]
        for f in ctrl: h = fwd(h, f)
        got, widths, why = recover(h, N)
        reasons[why] = reasons.get(why, 0) + 1
        if got != ctrl[::-1][:len(got)]: wrong += 1
        depths.append(len(got))
    from collections import Counter
    c = Counter(depths)
    print(f"3000 random runs, N = {N}, unknown seed: wrong controls recovered = {wrong}; stop reasons {reasons}")
    print(f"  recovered suffix length: min {min(depths)}, median {sorted(depths)[1500]}, max {max(depths)}")
    print("  histogram:", dict(sorted(c.items())))
    print(f"  mean recovered = {sum(depths)/len(depths):.2f} controls")

    # one trace: candidate-set width vs depth
    h = rng.randint(A_, B_); ctrl = [rng.choice(FS) for _ in range(N)]
    for f in ctrl: h = fwd(h, f)
    got, widths, why = recover(h, N)
    print(f"\nOne trace: recovered {len(got)} controls, then {why}. Candidate-set size by depth:")
    print("  ", [f"{w:.2g}" for w in widths])

    # short runs: whole control word recoverable when N <= guaranteed depth
    ok = 0
    for t in range(2000):
        n = rng.randint(1, jg); h = rng.randint(A_, B_); ctrl = [rng.choice(FS) for _ in range(n)]
        for f in ctrl: h = fwd(h, f)
        got, _, _ = recover(h, n)
        ok += (got == ctrl[::-1])
    print(f"\nShort runs (N <= {jg}): all controls recovered exactly in {ok}/2000")

    # --- Constant control: global convergence, made rigorous ---
    print("\nConstant control, every start in I:")
    for f in FS:
        F = Fr(f, 1000)
        # real fixed point by exact bisection on g(x) - x, g(x) = N(x)/10^42 (decreasing g, so g(x)-x is decreasing)
        lo, hi = Fr(A_), Fr(B_)
        g = lambda x: ((x*x - f*10**25)**2 - f*10**53) / Fr(D42)
        for _ in range(80):
            m = (lo + hi) / 2
            if g(m) - m > 0: lo = m
            else: hi = m
        xstar = lo
        L = max(4*Fr(B_,10**14)*(F - Fr(B_,10**14)**2), 4*Fr(A_,10**14)*(F - Fr(A_,10**14)**2))
        R = Fr(1, 2) / (1 - L)            # every orbit eventually enters |x - x*| <= R (+ tiny margin)
        c = round(xstar); W = 1000
        allfix = all(any(True for _ in [0]) for _ in [0])
        fps = set()
        for d in range(-W, W + 1):
            h = c + d
            for _ in range(60): h = fwd(h, f)
            fps.add(h)
        print(f"  F={f/1000}: x* = {float(xstar):.4f}, contraction L = {float(L):.4f}, absorbing radius 0.5/(1-L) = {float(R):.3f} units;"
              f" all {2*W+1} states within ±{W} of x* end at {sorted(fps)} (fixed: {all(fwd(p, f) == p for p in fps)})")
