#!/usr/bin/env python3
"""
True recovery horizon = shortest common control word w with w(e1) = w(e2), where e1 < e2 are the facing
endpoints of the two branch images (all maps monotone, so two branch images collide under w iff their
facing endpoints do).  Exact lattice search with exact pruning, plus a decomposition of the bound's slack.

Pruning: if the gap is g now, the next gap is > mu*g - 1 (each rounding moves < 1/2, slope >= mu).
So the gap can reach 0 within r steps only if g <= T_r, with T_0 = 0, T_r = floor((T_{r-1} + 1)/mu).
"""
import sys, math, time
from fractions import Fraction as Fr
from paper_checks import Q, lattice_constants, abs_slope, horizon, FS

def thresholds(mu, R):
    T = [0]
    for _ in range(R): T.append(int((Fr(T[-1]) + 1) / mu))
    return T

def exact_horizon(p, extra=4, budget=120):
    a, b, e1, e2, G = lattice_constants(p)
    mu = min(abs_slope(a, f, p) for f in FS)
    d, _ = horizon(mu, G)
    t0 = time.time()
    for D in range(d, d + extra + 1):
        T = thresholds(mu, D)
        nodes = 0; found = None
        stack = [(e1, e2, 0, ())]
        while stack:
            x, y, k, w = stack.pop(); nodes += 1
            if x == y: found = w; break
            if k == D: continue
            for f in FS:
                u, v = Q(x, f, p), Q(y, f, p)
                if u > v: u, v = v, u
                if v - u <= T[D - k - 1]: stack.append((u, v, k + 1, w + (f,)))
            if time.time() - t0 > budget: return d, None, nodes, None
        if found is not None:
            return d, D, nodes, found
    return d, '>' + str(d + extra), nodes, None

def path_profile(p, w):
    """Along the merging word: realised slopes and rounding gains vs the worst case."""
    a, b, e1, e2, G = lattice_constants(p)
    mu = min(abs_slope(a, f, p) for f in FS)
    x, y = Fr(e1), Fr(e2); xl, yl = e1, e2
    slopes = []; round_gain = 0.0
    for f in w:
        F = Fr(f, 1000); S = Fr(10**p)
        g = lambda z: S * ((z/S)**2 - F)**2 - S*F
        real = abs(float(g(Fr(xl)) - g(Fr(yl))))
        sig = real / (yl - xl) if yl != xl else float('nan')
        slopes.append(sig)
        xl2, yl2 = sorted((Q(xl, f, p), Q(yl, f, p)))
        round_gain += real - (yl2 - xl2)        # >0 means rounding narrowed the gap
        xl, yl = xl2, yl2
    gm = math.exp(sum(math.log(s) for s in slopes) / len(slopes))
    return float(mu), gm, round_gain

if __name__ == "__main__":
    print(" p | bound d(p) | true d*(p) | nodes | geo-mean slope on merge path vs mu | net rounding narrowing (units)")
    for p in range(6, 23):
        d, ds, nodes, w = exact_horizon(p)
        if w is not None:
            mu, gm, rg = path_profile(p, w)
            word = ''.join('L' if f == 1094 else 'H' for f in w)
            print(f"{p:2d} | {d:10} | {ds:10} | {nodes:7} | {gm:.6f} vs {mu:.6f} | {rg:+.2f}   w = {word}")
        else:
            print(f"{p:2d} | {d:10} | {str(ds):>10} | {nodes:7} | (not resolved within budget)")
        sys.stdout.flush()
