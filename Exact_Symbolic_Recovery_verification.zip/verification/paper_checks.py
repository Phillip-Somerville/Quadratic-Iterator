#!/usr/bin/env python3
"""
paper_checks.py -- verification script for "Exact Symbolic Recovery in a Finite-Precision
Contracting Quadratic Iterator".  Python 3 standard library only; exact integers and Fractions.
Run:  python3 paper_checks.py        (about 6 seconds)

Checks, in paper order:
  S2  Lemmas 2-4: endpoint images, slope constants mu and M on D, gap G
  S3  Theorem 1: the n_j recurrence; Proposition 2: the 27-step witness
      Theorem 3: d(p) for 6 <= p <= 22 from lattice constants at each precision
  S4  Proposition 4: forgetting bound k(p)
  S7  Proposition 8: |S_n| by exact interval arithmetic, n = 1..20
"""
import math
from fractions import Fraction as Fr

# ---------------------------------------------------------------- the map at precision p
def Q(h, f, p=14):
    """round_half_even( ((h^2 - f*10^(2p-3))^2 - f*10^(4p-3)) / 10^(3p) )"""
    d = 10**(3*p)
    q, r = divmod((h*h - f*10**(2*p - 3))**2 - f*10**(4*p - 3), d)
    if 2*r > d or (2*r == d and q & 1): q += 1
    return q

def abs_slope(x, f, p):
    """|g_f'(x)| = 4H(F - H^2), H = x/10^p (exact)."""
    H = Fr(x, 10**p); F = Fr(f, 1000)
    return 4*H*(F - H*H)

A_, B_ = 8546797095098, 8925729498786
FS = (1094, 1096)

def lattice_constants(p):
    """2-cycle hull I_p = [a, b] (a = Q(b,1094), b = Q(a,1096)), inner image endpoints, gap G."""
    a = A_ * 10**p // 10**14 if p <= 14 else A_ * 10**(p - 14)
    b = Q(a, 1096, p)
    for _ in range(500):
        a2 = Q(b, 1094, p); b2 = Q(a2, 1096, p)
        if (a2, b2) == (a, b): break
        a, b = a2, b2
    assert Q(b, 1094, p) == a and Q(a, 1096, p) == b
    e1, e2 = Q(a, 1094, p), Q(b, 1096, p)
    return a, b, e1, e2, e2 - e1

def horizon(mu, G):
    """Largest number of forced controls: n_0 = 1, n_{j+1} = floor(n_j/mu) + 1, forced while n_j <= G."""
    n, j, seq = 1, 0, [1]
    while True:
        n2 = int(Fr(n) / mu) + 1
        if n2 > G: return j + 1, seq + [n2]
        n, j = n2, j + 1; seq.append(n)

# ---------------------------------------------------------------- recovery procedure (Section 3)
def images(p=14):
    a, b, e1, e2, G = lattice_constants(p)
    return {1094: (a, e1), 1096: (e2, b)}, a, b

def preimage(lo, hi, f, a, b, p=14):
    """{h in [a,b] : lo <= Q(h,f) <= hi}, an interval since Q is non-increasing on I."""
    L, R = a, b + 1
    while L < R:
        m = (L + R) // 2
        if Q(m, f, p) <= hi: R = m
        else: L = m + 1
    h1 = L
    L, R = a - 1, b
    while L < R:
        m = (L + R + 1) // 2
        if Q(m, f, p) >= lo: L = m
        else: R = m - 1
    return (h1, L) if h1 <= L else None

def recover(hN, maxdepth, p=14):
    E, a, b = images(p)
    C, out = (hN, hN), []
    for _ in range(maxdepth):
        hits = [f for f in FS if not (C[1] < E[f][0] or C[0] > E[f][1])]
        if len(hits) != 1: break
        f = hits[0]; out.append(f)
        C = preimage(max(C[0], E[f][0]), min(C[1], E[f][1]), f, a, b, p)
        if C is None: break
    return out          # out[0] = last control

# ---------------------------------------------------------------- reachable sets (Section 7)
def merge(iv):
    iv.sort(); out = []
    for lo, hi in iv:
        if out and lo <= out[-1][1] + 1: out[-1] = (out[-1][0], max(out[-1][1], hi))
        else: out.append((lo, hi))
    return out

def reachable_counts(nmax):
    S = [(A_, B_)]; counts = {}
    for n in range(1, nmax + 1):
        S = merge([(Q(hi, f), Q(lo, f)) for lo, hi in S for f in FS])   # Q non-increasing
        counts[n] = (sum(hi - lo + 1 for lo, hi in S), len(S))
    return counts

if __name__ == "__main__":
    print("== Section 2: Lemmas 2-4 at p = 14 ==")
    a, b, e1, e2, G = lattice_constants(14)
    assert (a, b) == (A_, B_)
    print(f"  I = [{a}, {b}],  E_1094 = [{a}, {e1}],  E_1096 = [{e2}, {b}],  G = {G}")
    mu = min(abs_slope(A_ - 2, f, 14) for f in FS); M = max(abs_slope(B_ + 2, f, 14) for f in FS)
    print(f"  mu = {float(mu):.12f},  M = {float(M):.12f}  (on D = [a-2, b+2])")
    assert M < 1 and e1 < 8781000000000 < e2

    print("\n== Section 3: Theorem 1 and Proposition 2 ==")
    d, seq = horizon(mu, G)
    print(f"  n_23..n_26 = {seq[23:27]};  G = {G};  horizon = {d}")
    assert d == 26
    word = "LLLHLLLLLLLLHLHLLLHLHHLHHH"
    ctrl = [1094 if c == 'L' else 1096 for c in word]
    x1, x2 = A_, B_
    x1 = Q(x1, 1094); x2 = Q(x2, 1096)
    for f in ctrl: x1, x2 = Q(x1, f), Q(x2, f)
    print(f"  witness: from a with L + w -> {x1};  from b with H + w -> {x2};  equal: {x1 == x2}")
    assert x1 == x2 == 8834117726612
    got = recover(x1, 40)
    print(f"  recovery from the witness end state stops after {len(got)} controls (expected 26)")
    assert len(got) == 26 and got == ctrl[::-1][:26]

    print("\n== Section 3: Theorem 3, d(p) from lattice constants at each p ==")
    print("   p | G_p                     | mu_p (on I_p) | d(p) exact | closed form")
    for p in range(6, 23):
        a, b, e1, e2, Gp = lattice_constants(p)
        mup = min(abs_slope(a, f, p) for f in FS)
        Mp = max(abs_slope(b, f, p) for f in FS)
        assert Mp < 1 and e1 < e2
        dp, _ = horizon(mup, Gp)
        cf = 1 + math.floor(math.log(Gp * (1 - float(mup))) / math.log(1 / float(mup)))
        assert cf <= dp
        print(f"  {p:2d} | {Gp:<23} | {float(mup):.10f}  | {dp:>10} | {cf:>11}")

    print("\n== Section 4: Proposition 4, forgetting bound k(p) ==")
    for p in range(6, 23, 2):
        a, b, _, _, _ = lattice_constants(p)
        Mp = max(abs_slope(b, f, p) for f in FS)
        k = 0
        while Mp**k * (b - a) + (1 - Mp**k) / (1 - Mp) >= 2: k += 1
        print(f"  p = {p:2d}: two starts under any shared word of length k >= {k} are equal or adjacent")

    print("\n== Section 7: Proposition 8, exact |S_n| ==")
    counts = reachable_counts(20)
    for n in (1, 2, 4, 10, 16, 20):
        c, nint = counts[n]
        print(f"  n = {n:2d}: |S_n| = {c:,}  (log2 = {math.log2(c):.3f}; {nint} intervals)")
    assert counts[1][0] == 287973462886 and counts[20][0] == 1565000449
    print(f"  |I| = {B_ - A_ + 1:,};  log2|I| - log2|S_1| = {math.log2(B_ - A_ + 1) - math.log2(counts[1][0]):.4f}")
    print("\nALL PAPER CHECKS PASSED")
