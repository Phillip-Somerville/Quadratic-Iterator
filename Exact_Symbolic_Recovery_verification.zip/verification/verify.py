#!/usr/bin/env python3
"""Standalone verifier for Encoder A' (exact integer lattice model).  No dependencies beyond the
Python 3 standard library.  Run:  python3 verify.py     Expected last line:  ALL CHECKS PASSED"""
from math import isqrt
import hashlib
A, B = 8546797095098, 8925729498786          # invariant interval I = [A, B]
T = 8781000000000                             # threshold 0.08781
SEED = 8780100000000                          # canonical seed 0.087801
R = 64                                        # forced-run cap
D42 = 10**42

def fwd(h, f):
    """round_half_even( ((h^2 - f*10^25)^2 - f*10^53) / 10^42 )"""
    n = (h*h - f*10**25)**2 - f*10**53
    q, r = divmod(n, D42)
    if 2*r > D42 or (2*r == D42 and q & 1): q += 1
    return q

def reg(h): return 1096 if h > T else 1094

def k_of(hp):
    """nearest integer to 10^14 * sqrt(F - sqrt(hp/10^14 + F)), F = reg(hp)/1000, via integer square roots"""
    f = reg(hp); P = 40
    a = isqrt((hp + f*10**11) * 10**(2*P - 14))
    x = isqrt((f*10**(P-3) - a) * 10**P)          # x = 10^P * H
    q, r = divmod(x, 10**(P-14))
    return q + (1 if 2*r >= 10**(P-14) else 0)

def sgn(v): return (v > 0) - (v < 0)

def encode(seed, bits):
    assert A <= seed <= B and len(bits) >= 1
    H = [seed, fwd(seed, 1096 if bits[0] else 1094)]; J = [None, 0]; kind = [None, 'T']; bi = 1; run = 0
    while bi < len(bits):
        j = sgn(k_of(H[-1]) - H[-2])
        if run == R:   f = 1096 if bits[bi] else 1094; bi += 1; run = 0; kind.append('O')
        elif j != 0:   f = 1096 if j == 1 else 1094; run += 1; kind.append('C')
        else:          f = 1096 if bits[bi] else 1094; bi += 1; run = 0; kind.append('T')
        H.append(fwd(H[-1], f)); J.append(j)
    N = len(H) - 1
    cert = dict(exit=H[N], N=N, jhang=sgn(k_of(H[N]) - H[N-1]),
                flags=[abs(J[m]) for m in range(2, N)],
                last=[abs(J[N])] if N >= 2 and kind[N] == 'O' else [],
                esc=[int(J[m] == 1) for m in range(2, N+1) if kind[m] == 'O' and J[m] != 0])
    return cert, H, kind

def decode(cert):
    N = cert['N']; f = {m: cert['flags'][m-2] for m in range(2, N)}; kind = {1: 'T'}; run = 0
    for m in range(2, N+1):
        if run == R:
            kind[m] = 'O'; run = 0
            if m == N: f[N] = cert['last'][0]
        elif m < N and f[m] == 1: kind[m] = 'C'; run += 1
        else:
            kind[m] = 'T'; run = 0
            if m == N: f[N] = 0
    esc = list(cert['esc']); H = {N: cert['exit']}
    H[N-1] = k_of(H[N]) - cert['jhang']
    for m in range(N, 1, -1):
        k = k_of(H[m-1])
        if f[m] == 0:          H[m-2] = k
        elif kind[m] == 'C':   H[m-2] = k - (1 if reg(H[m]) == 1096 else -1)
        else:                  H[m-2] = k - (1 if esc.pop() else -1)
    return H[0], [int(reg(H[m]) == 1096) for m in range(1, N+1) if kind[m] in 'TO']

def bits_of(text): return [(c >> (7-i)) & 1 for c in text.encode() for i in range(8)]
def lcg_bits(n, s=12345):
    out = []
    for _ in range(n):
        s = (1103515245*s + 12345) % 2**31; out.append((s >> 16) & 1)
    return out
def digest(cert):
    s = "%d|%d|%d|%s|%s|%s" % (cert['exit'], cert['N'], cert['jhang'], "".join(map(str, cert['flags'])),
                               "".join(map(str, cert['last'])), "".join(map(str, cert['esc'])))
    return hashlib.sha256(s.encode()).hexdigest()

# ---- deterministic test vectors ----
FWD = [(8546797095098, 1094, 8690651408410), (8546797095098, 1096, 8925729498786), (8925729498786, 1094, 8546797095098), (8925729498786, 1096, 8781610349214), (8780100000000, 1094, 8602810278655), (8780100000000, 1096, 8837726672414)]
KV = [(8651513194461, 8651513194460), (8602810278654, 8780100000002), (8837726672414, 8780100000001), (8925729498786, 8546797095099), (8546797095098, 8925729498785)]
VEC = [('A', 8780100000000, 8, 16, 8884734245246, 0, 0, '01111100011001', 'c209a3e841ea4b8451520ad98435d7117317719d2a1f3033d73e2ff16933c428'), ('Alice', 8780100000000, 40, 112, 8871859596929, 0, 0, None, '2533fadea6f3910fad0e03c67498b4444cf3d9641c8d5430d4649d01c3e01afe'), ('trap', 8651513194460, 3, 67, 8886519247238, 1, 1, '01111111111111111111111111111111111111111111111111111111111111111', '30f888872bae3727f7d5afb2511e60d247d22fe14f07360a14450417ed465958'), ('lcg4000', 8780100000000, 4000, 10752, 8788761157867, 0, 0, None, '13fe829fdc4087cfb1360e119ac53b30c6b64550177258208a39f396ec46d1a7'), ('zeros64', 8780100000000, 64, 154, 8651602751901, 0, 0, None, '3d0f5743f2dc247ea278d70f05ec4f0220e6a4b2bbbe702a11389a14dccf1a92'), ('ones64', 8780100000000, 64, 185, 8821813899081, -1, 0, None, 'd9387d57cc29ab5d80bf062c921207ee836d9ef96d67c26dfeb7b6b0db528160')]

PAY = {"A": bits_of("A"), "Alice": bits_of("Alice"), "trap": [0, 0, 1], "lcg4000": lcg_bits(4000), "zeros64": [0]*64, "ones64": [1]*64}
if __name__ == "__main__":
    for h, f, e in FWD: assert fwd(h, f) == e
    for h, e in KV: assert k_of(h) == e
    print("forward-map and inverse-candidate vectors: ok")
    for name, seed, L, N, ex, jh, nov, flags, dg in VEC:
        c, H, kind = encode(seed, PAY[name])
        assert (c['N'], c['exit'], c['jhang'], kind.count('O')) == (N, ex, jh, nov), name
        assert flags is None or "".join(map(str, c['flags'])) == flags, name
        assert digest(c) == dg, name
        assert all(A <= h <= B for h in H), name
        assert decode(c) == (seed, PAY[name]), name
        assert N <= 1 + (R + 1) * (L - 1)
        print("vector %-8s L=%-5d N=%-6d exit=%d jHang=%+d overrides=%d : ok" % (name, L, N, ex, jh, nov))
    n = 0
    for L in range(1, 11):
        for v in range(1 << L):
            bits = [(v >> i) & 1 for i in range(L)]; c, H, kind = encode(SEED, bits); n += 1
            assert decode(c) == (SEED, bits)
    print("exhaustive round trip, canonical seed, all %d payloads with L <= 10: ok" % n)
    print("ALL CHECKS PASSED")
