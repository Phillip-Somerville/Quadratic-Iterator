#!/usr/bin/env python3
"""Properly weighted rounding analysis along the merging words found by alignment.py.
Along a merging word, with lattice gap g_k and secant slope s_k = |g_f(x_k) - g_f(y_k)| / g_k,
  g_{k+1} = s_k * g_k - r_k,   r_k = (real gap after step k) - (lattice gap after step k).
Unrolling to the merge (g_D = 0) gives the exact identity
  sum_k r_k * prod_{i>k} s_i  =  G * prod_k s_k  =: R,
so R is the gap that contraction alone (along the realised secant slopes) would leave at the merge depth,
and the contraction-weighted rounding contributions add up to exactly R."""
import re
from fractions import Fraction as Fr
from paper_checks import Q, lattice_constants

def analyse(p, word):
    a, b, e1, e2, G = lattice_constants(p)
    x, y = e1, e2; prod = Fr(1); terms = []
    S = 10**p
    for c in word:
        f = 1094 if c == 'L' else 1096
        F = Fr(f, 1000)
        g = lambda z: S * ((Fr(z, S))**2 - F)**2 - S*F
        real = abs(g(x) - g(y)); s = real / (y - x)
        u, v = sorted((Q(x, f, p), Q(y, f, p)))
        terms.append((s, real - (v - u)))
        prod *= s; x, y = u, v
    assert x == y
    R = G * prod
    # weighted sum check
    W = Fr(0)
    for k, (s, r) in enumerate(terms):
        tail = Fr(1)
        for s2, _ in terms[k+1:]: tail *= s2
        W += r * tail
    assert W == R
    return float(R), max(abs(float(r)) for _, r in terms)

if __name__ == "__main__":
    import os
    src = 'alignment_output.txt' if os.path.exists('alignment_output.txt') else 'expected_alignment_output.txt'
    for line in open(src):
        m = re.match(r'\s*(\d+) \|.*w = ([LH]+)', line)
        if m:
            p, w = int(m.group(1)), m.group(2)
            R, rmax = analyse(p, w)
            print(f"p={p:2d}: |w|={len(w)}, contraction-only residual gap R = {R:.3f} units (largest single rounding {rmax:.3f})")
