#!/bin/sh
# Reproduce every computational claim in the paper, in paper order.
# Requires Python 3.8+ (standard library only). Total time: about 4-10 minutes, mostly alignment.py.
cd "$(dirname "$0")" || exit 1
run() {  # run <script> <output file> <title>
  echo "== $3 =="
  python3 "$1" > "$2" 2>&1; status=$?
  cat "$2"
  if [ $status -ne 0 ]; then echo "FAILED: $1 (exit $status)"; exit $status; fi
}
run verify.py            out_verify.txt            "1. verify.py: Encoder A' reference (Theorem 5)"
run paper_checks.py      out_paper_checks.txt      "2. paper_checks.py: Lemmas, Theorems 1 and 3, Propositions 2, 4, 8"
run alignment.py         alignment_output.txt      "3. alignment.py: Proposition 2'' exact optimal horizons"
run rounding_weighted.py out_rounding_weighted.txt "4. rounding_weighted.py: weighted rounding identity"
run closed_loop.py       out_closed_loop.txt       "5. closed_loop.py: Theorem 7 tests"
run recover.py           out_recover.txt           "6. recover.py: sampled recovery depths (computed claims, Section 3)"
echo "ALL STEPS COMPLETED. Compare alignment_output.txt with expected_alignment_output.txt."
