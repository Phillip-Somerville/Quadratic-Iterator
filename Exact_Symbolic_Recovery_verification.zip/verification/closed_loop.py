#!/usr/bin/env python3
"""
Closed-loop Encoder A' versus open-loop symbolic recovery.  verify.py is imported unchanged (frozen reference).
Run from this folder:  python3 closed_loop.py

Indexing (verify.py): H[m] = fwd(H[m-1], f_m), m = 1..N; step kinds T (payload), C (forced by J), O (override).
"""
import random, sys
from collections import Counter
from verify import encode, decode, fwd, reg, k_of, sgn, A, B, SEED, R, PAY
from recover import recover

def fseq(H):
    """The control actually used at each step m = 1..N, read off the state it produced (register lemma)."""
    return [reg(H[m]) for m in range(1, len(H))]

def payload_runs(n_runs, L, rng, seed=None):
    for _ in range(n_runs):
        bits = [rng.randint(0, 1) for _ in range(L)]
        s = seed if seed is not None else rng.randint(A, B)
        yield s, bits

if __name__ == "__main__":
    rng = random.Random(1118)

    # 1. Branch recovery from the exit alone, on closed-loop runs
    print("== 1. Exit alone: how many final controls f_N, f_(N-1), ... does open-loop recovery return? ==")
    depths, wrong, kinds_in_window = [], 0, Counter()
    for s, bits in payload_runs(1000, 200, rng):
        c, H, kind = encode(s, bits)
        F = fseq(H)
        got, _, _ = recover(c['exit'], len(F))
        if got != F[::-1][:len(got)]: wrong += 1
        depths.append(len(got))
        for m in range(len(H) - 1 - 25, len(H)): kinds_in_window[kind[m]] += 1
    print(f"  1000 runs (random seed in I, 200 random bits): wrong = {wrong}; depth min {min(depths)}, "
          f"median {sorted(depths)[500]}, max {max(depths)}, mean {sum(depths)/1000:.2f}")
    tot = sum(kinds_in_window.values())
    print(f"  step kinds in the last 26 steps: " + ", ".join(f"{k}={v/tot:.3f}" for k, v in sorted(kinds_in_window.items())))

    # 2. The sign of every C-step correction is the branch symbol of the state it produces
    print("\n== 2. For C steps, is sign(J[m]) equal to the branch of H[m]? ==")
    agree = total = 0
    for s, bits in payload_runs(300, 200, rng):
        c, H, kind = encode(s, bits)
        for m in range(2, len(H)):
            if kind[m] == 'C':
                j = sgn(k_of(H[m-1]) - H[m-2]); total += 1
                agree += (j == (1 if reg(H[m]) == 1096 else -1))
    print(f"  {agree}/{total} C steps: correction sign = branch symbol of the next state")

    # 3. Wrong jHang: the reference decoder raises (states leave I); trace its backward recursion instead
    print("\n== 3. Decode with a corrupted jHang: how many final branch symbols does the decoder still get right? ==")
    good = []
    for s, bits in payload_runs(400, 120, rng):
        c, H, kind = encode(s, bits); N = c['N']
        for jh in (-1, 0, 1):
            if jh == c['jhang']: continue
            Hd = {N: c['exit'], N-1: k_of(c['exit']) - jh}; m = N; n_ok = 0
            try:
                while m >= 2:
                    if reg(Hd[m]) != reg(H[m]): break
                    n_ok += 1
                    k = k_of(Hd[m-1]); J = abs(sgn(k_of(H[m-1]) - H[m-2])) if m >= 2 else 0
                    sign = (1 if reg(Hd[m]) == 1096 else -1) if kind[m] == 'C' else (sgn(k_of(H[m-1]) - H[m-2]))
                    Hd[m-2] = k - (sign if J else 0)
                    if not (A <= Hd[m-2] <= B): m -= 1; break
                    m -= 1
            except Exception:
                pass
            good.append(n_ok)
    print(f"  {len(good)} corrupted decodes: final branch symbols still correct: min {min(good)}, "
          f"median {sorted(good)[len(good)//2]}, max {max(good)}")
    print("  (the reference decode() raises in every such case, because the backward states leave I)")

    # 4. Linear-time suffix decoding: seed + bits consumed up to step N-26 + N + exit; no tail flags, no search
    print("\n== 4. Tail decoding without the tail certificate: replay the closed loop along the recovered branch word ==")
    W = 26
    def tail_decode(seed, prefix_bits, N, exit_):
        w = min(W, N)
        F = recover(exit_, w)[0][::-1]                      # f_(N-w+1) .. f_N
        fstep = lambda m: F[m - (N - w) - 1]
        if N - w >= 1: f1 = 1096 if prefix_bits[0] else 1094; out = [prefix_bits[0]]; bi = 1
        else:          f1 = fstep(1); out = [int(f1 == 1096)]; bi = 0
        H = [seed, fwd(seed, f1)]; run = 0
        for m in range(2, N + 1):
            j = sgn(k_of(H[-1]) - H[-2])
            if m <= N - w:
                if run == R or j == 0:
                    f = 1096 if prefix_bits[bi] else 1094; out.append(prefix_bits[bi]); bi += 1; run = 0
                else: f = 1096 if j == 1 else 1094; run += 1
            else:
                f = fstep(m)
                if run == R or j == 0: out.append(int(f == 1096)); run = 0
                else:
                    assert f == (1096 if j == 1 else 1094); run += 1
            H.append(fwd(H[-1], f))
        assert H[-1] == exit_
        return out
    ok = tried = 0; tailbits = []
    for s, bits in payload_runs(1000, 150, rng, seed=SEED):
        c, H, kind = encode(s, bits)
        N = c['N']
        n_prefix = sum(1 for m in range(1, N - min(W, N) + 1) if kind[m] in 'TO')
        tried += 1
        got = tail_decode(s, bits[:n_prefix], N, c['exit'])
        ok += (got == bits); tailbits.append(len(bits) - n_prefix)
    print(f"  {ok}/{tried} payloads recovered exactly; payload bits in the 26-step tail: "
          f"min {min(tailbits)}, mean {sum(tailbits)/len(tailbits):.2f}, max {max(tailbits)}")
    # the reference vectors too
    for name in ('A', 'Alice', 'lcg4000', 'zeros64', 'ones64', 'trap'):
        bits = PAY[name]; seed = 8651513194460 if name == 'trap' else SEED
        c, H, kind = encode(seed, bits); N = c['N']
        n_prefix = sum(1 for m in range(1, N - min(W, N) + 1) if kind[m] in 'TO')
        got = tail_decode(seed, bits[:n_prefix], N, c['exit'])
        print(f"  vector {name:8s}: N={N}, tail bits recovered = {len(bits)-n_prefix}, exact = {got == bits}")
