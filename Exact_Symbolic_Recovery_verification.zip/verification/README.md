# Verification archive

**Paper:** *Exact Symbolic Recovery in a Finite-Precision Contracting Quadratic Iterator* (P. Somerville, November 2026).

These scripts reproduce every computational claim in the paper. They need Python 3.8 or later and nothing else. All arithmetic is exact (integers and `fractions.Fraction`); no floating-point value decides any reported result.

## How to run

```
sh run_all.sh
```

This takes about 4–10 minutes, depending on the machine; most of it is `alignment.py`. The node count printed for p = 21 depends on machine speed, because that search stops at its time limit. Each script can also be run on its own, in the order below. Each script prints the output listed, and its full expected output is in the matching `expected_*` file. Asserts stop a script if any exact check fails.

| # | Script | Paper result | Expected output |
|---|---|---|---|
| 1 | `verify.py` (frozen reference, unchanged) | Theorem 5: Encoder A′ terminates and reconstructs seed and payload | `ALL CHECKS PASSED` |
| 2 | `paper_checks.py` | Lemmas 2–4 and constants (μ, M, G); Theorem 1's recurrence (n₂₅ = 73,532,104,874 ≤ G < n₂₆); the Proposition 2 witness; Theorem 3's d(p) for 6 ≤ p ≤ 22; Proposition 4's forgetting bounds; Proposition 8's \|S_n\| for n ≤ 20 | `ALL PAPER CHECKS PASSED` |
| 3 | `alignment.py` | Proposition 2″: the optimal horizon d*(p) for 6 ≤ p ≤ 22, with merging words | Matches `expected_alignment_output.txt`; p = 21 ends with "not resolved within budget" |
| 4 | `rounding_weighted.py` | The weighted rounding identity (§3) | For each p, a residual gap R between 0.62 and 1.32 |
| 5 | `closed_loop.py` (imports `verify.py`, `recover.py`) | Theorem 7 tests; forced-step signs equal next-state branch symbols | 1000/1000 payloads exact; all six reference vectors exact |
| 6 | `recover.py` | Sampled recovery depths, quoted in §3 as computed only | Depths 26–32, no wrong control |

`witness_search.py` is not needed for any claim in the final paper. It is kept because it produced the first sharpness witnesses.

## Status of each result

| Paper result | Kind of evidence |
|---|---|
| Lemmas 1–6; Theorems 1, 3, 5, 7; Propositions 2′, 4; Corollary 6 | Proved in the paper. The scripts check only the numerical constants the proofs use. |
| Proposition 2 (27-step collision at p = 14) | Exact certificate: an explicit pair of runs, checked by exact forward iteration |
| Theorem 3's hypotheses at p ≠ 14 | Exact computation of each lattice 2-cycle, its image endpoints and slope bounds |
| Proposition 2″ (d*(p), 6 ≤ p ≤ 22, p ≠ 21) | Exact exhaustive search with proved pruning; each merging word is checked by forward iteration |
| Proposition 8 counts | Exact interval arithmetic |
| Recovery depths 26–32; merging of random pairs within 34–40 steps | Sampled, not proved |
| Lattice-alignment pattern; R values | Descriptive observations, not theorems |
| ~2²⁸ eventually reachable states; fractal dimension | Extrapolated; not checked here |

## Completeness of the exact searches (Proposition 2″)

`alignment.py` searches over every control word applied to the facing endpoints (e₁, e₂). Proposition 2′ in the paper proves that the shortest word making them equal is the optimal horizon.

- **Pruning.** If the current gap is g, the next gap is more than μg − 1, because both states lie in I_p, the slope there is at least μ, and each rounding moves a value by at most 1/2. Define T₀ = 0 and T_r = ⌊(T_(r−1) + 1)/μ⌋. Then a gap larger than T_r cannot reach 0 within r steps, by induction on r. So discarding such branches loses no merge.
- **Search order.** Theorem 1 rules out merges before the bound d(p). The search therefore runs depth limits D = d(p), d(p) + 1, … in turn. The first D at which a merge is found is d*(p), and that merge is checked by forward iteration.
- **Termination.** A search counts as complete only when it finishes within its time budget, which is 120 s per precision. Every precision from 6 to 22 except 21 finished. At p = 21 the search stopped at the budget, so d*(21) is unresolved.

## Provenance

The scripts were written with AI assistance (principally Claude, by Anthropic) under the author's direction. They have been run and cross-checked only in AI-assisted review. They have not yet been independently verified by an outside mathematician or programmer. Reports of errors, failed runs or counterexamples are welcome.
